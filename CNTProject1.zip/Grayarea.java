/* Name: Riya Sawant
Course: CNT 4714 – Spring 2024
Assignment title: Project 1 – An Event-driven Enterprise Simulation
Date: Sunday January 28, 2024
*/

package enterprise;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter; 
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Date;
import java.text.NumberFormat;
import java.util.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class Grayarea extends JFrame{
	
	
	private static final int WIDTH = 700;
	private static final int HEIGHT = 600; 
			

	private JLabel blankLabel, IDLabel, QTLabel, itemLabel, totalLabel;
	private JButton processB, confirmB, viewB, finishB, newb, exitB;
	private JTextField blankTextField, IDTextField, QTTextField, itemTextField, totalTextField;
	
	private JTextField space1,space2,space3,space4,space5;
	
	private ProcessButtonHandler procbHandler;
    private ConfirmButtonHandler confbHandler;
    private ViewButtonHandler viewBHandler;
    private FinishButtonHandler finbHandler;
    private NewButtonHandler newbHandler;
    private ExitButtonHandler exitBHandler;
    // private SpaceHandler spaceHandler;
    
    static int itemCount=0 ,itemQuantity=0, itemQtyOnHand=0, maxArraySize=0, fileRowCounter=0;
  

	//array
    static String [] itemIDArray = new String[50];
    static String [] itemTitleArray = new String[50];
    
    static String [] itemInStockArray = new String[50];
    static double [] itemPriceArray = new double[50];
    static int [] itemQuantityArray = new int[50];
    
    static double [] itemDiscountArray = new double[50];
    static double [] itemSubtotalArray = new double[50];
	
    //static int itemCount=0 ,itemQuantity=0, itemQtyOnHand=0, maxArraySize=0, fileRowCounter=0;
    static String itemID = "", itemQuantityStr =	"",maxArraySizeStr = "",itemTitle = "", 
    	    itemPriceStr = "", itemInStock = "", itemSubtotalStr = "", itemDiscountStr = "",
    	    taxRateStr, discountRateStr, orderSubString;
    
    static double itemPrice=0, itemSubtotal=0, orderSubtotal=0, orderTotal=0, itemDiscount=0, orderTaxAmount;
    
   
  //static variables 
  	static NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
  	static NumberFormat percentFormatter = NumberFormat.getPercentInstance();
  	static DecimalFormat decimalFormatter = (DecimalFormat) percentFormatter;
    
    
   
	final static double TAX_RATE = 0.060, DISCOUNT_FOR_05 = 0.10, DISCOUNT_FOR_10 = 0.15, DISCOUNT_FOR_15 = 0.20;
	
	String fileName;
	
//******************************************************************************************************************************************************//
	
	public Grayarea()   
	{
		
		setTitle("Nile Dot Com - Spring 2024"); 
		setSize(WIDTH, HEIGHT); 
				
		
		//JLabel objects
		blankLabel = new JLabel("", SwingConstants.RIGHT);
		IDLabel = new JLabel("Enter item ID for Item #" + (itemCount+1) + ":", SwingConstants.RIGHT);
		QTLabel = new JLabel("Enter quantity for Item #" + (itemCount+1) + ":", SwingConstants.RIGHT);
		itemLabel = new JLabel("Details for Item #" + (itemCount+1) + ":", SwingConstants.RIGHT);
		totalLabel = new JLabel("Order subtotal for " + itemCount + " item(s):", SwingConstants.RIGHT);
		
    	//instantiate JTextField objects 
    	blankTextField = new JTextField();
    	IDTextField = new JTextField();
    	QTTextField = new JTextField();
    	itemTextField = new JTextField();
    	totalTextField = new JTextField();
		
    	//----------
    	space1 = new JTextField();
    	space2 = new JTextField();
    	space3 = new JTextField();
    	space4 = new JTextField();
    	space5 = new JTextField();
    	//----------------
    	
    
    	processB = new JButton("Find Item #" + (itemCount+1));
    	procbHandler = new ProcessButtonHandler();
    	processB.addActionListener(procbHandler);
    	
    	confirmB = new JButton("Add Item #" + (itemCount+1) + " To Cart");
    	confbHandler = new ConfirmButtonHandler();
    	confirmB.addActionListener(confbHandler);
    	
    	viewB = new JButton("View Cart");
    	viewBHandler = new ViewButtonHandler();
    	viewB.addActionListener(viewBHandler);
    	
    	finishB = new JButton("Check Out");
    	finbHandler = new FinishButtonHandler();
    	finishB.addActionListener(finbHandler);
    	
    	newb = new JButton("Empty Cart - Start A New Order");
    	newbHandler = new NewButtonHandler();
    	newb.addActionListener(newbHandler);
    	
    	exitB = new JButton("Exit (Close App)");
    	exitBHandler = new ExitButtonHandler();
    	exitB.addActionListener(exitBHandler);
	
    	
    	confirmB.setEnabled  (false); 
    	viewB.setEnabled  (false); 
    	finishB.setEnabled  (false); 
    	itemTextField.setEditable (false);
		totalTextField.setEditable (false);
		
		blankTextField.setEditable (false);
		blankTextField.setVisible (true);
		
		
		
		Container pane = getContentPane();
		
		//GridLayout grid5by2 = new GridLayout(5,2);
		//GridLayout grid3by2 = new GridLayout(3,2);
		GridLayout grid5by2 = new GridLayout(6, 2, 8, 4);
        GridLayout grid7by2 = new GridLayout(7, 2, 8, 4);
        GridLayout grid2by2 = new GridLayout(6, 2, 8, 4);
		
		
		//panels
		JPanel northPanel = new JPanel();
		JPanel centralPanel = new JPanel();
		JPanel southPanel = new JPanel();
		
		//layout for panels
		northPanel.setLayout(grid5by2);
		centralPanel.setLayout(grid7by2); //chage late?
		southPanel.setLayout(grid2by2);
		
		//add panels to content pane using BorderLayput
		pane.add(northPanel, BorderLayout.NORTH);
		pane.add(centralPanel, BorderLayout.CENTER);
		pane.add(southPanel, BorderLayout.SOUTH);
		
		//background
		northPanel.setBackground(Color.DARK_GRAY);
		pane.setBackground(Color.DARK_GRAY);		
		southPanel.setBackground(Color.GREEN);
		blankTextField.setBackground (Color.DARK_GRAY);
		
		centerFrame(WIDTH, HEIGHT); 
		
		//add north labels to panel
		
		northPanel.add(IDLabel);
		northPanel.add(IDTextField);
		northPanel.add(QTLabel);
		northPanel.add(QTTextField);
		northPanel.add(itemLabel);
		northPanel.add(itemTextField);
		northPanel.add(totalLabel);
		northPanel.add(totalTextField);
		northPanel.add(blankLabel);
		northPanel.add(blankTextField);
		
	
		IDLabel.setForeground(Color.YELLOW);
		QTLabel.setForeground(Color.YELLOW);
		itemLabel.setForeground(Color.RED);
		totalLabel.setForeground(Color.RED);
		
		
		centralPanel.add(space1);
		centralPanel.add(space2);
		centralPanel.add(space3);
		centralPanel.add(space4);
		centralPanel.add(space5);
		
		//add 
    	southPanel. add (processB);
    	southPanel.add (confirmB);
    	southPanel.add(viewB);
    	southPanel.add (finishB);
    	southPanel.add (newb);
    	southPanel.add (exitB);	
		
	}

//********************************************************************************************************//
	
    private class ProcessButtonHandler implements ActionListener {  
        public void actionPerformed(ActionEvent e) {
           
            try {
               
            	String csvFilePath = "inventory.csv";
            	FileReader fileReader = new FileReader(csvFilePath);
            	BufferedReader bufferedReader = new BufferedReader(fileReader);
                String line;
                Boolean FoundId = false;
                int currentItemIndex = 0;
                
                
                while ((line = bufferedReader.readLine())!= null) 
                {
                 
                    String[] fields = line.split(",");
                    itemID = fields[0].trim();
                    itemTitle = fields[1].trim();
                    itemPrice = Double.parseDouble(fields[4].trim());
                    itemQtyOnHand = Integer.parseInt(fields[3].trim());
                   itemInStock = fields[2].trim();
                    
                    
                    System.out.println(itemID);
                    System.out.println(itemInStock);
                
                 
                    
                    if (itemID.equals(IDTextField.getText().trim()))
                    {
                    	 FoundId = true;
                    }
                  
                    
             
                    if (itemID.equals(IDTextField.getText().trim()) && itemInStock.equals("false")){
                    	System.out.println("here");
                    	FoundId = true;
                    	JOptionPane.showMessageDialog(null, "Sorry... that item is out of stock, please try another item", "Nile Dot Com - ERROR ", JOptionPane.ERROR_MESSAGE);
                    	IDTextField.setText("");
               		    QTTextField.setText("");
                    	currentItemIndex++;
                    	break;
                    }
               
                    if (itemID.equals(IDTextField.getText().trim()) && itemQtyOnHand > 0) {
                        IDTextField.setText(itemID);
                        itemQuantity = Integer.parseInt(QTTextField.getText());
                        double discount = 0;
                       
                            if (itemQuantity > itemQtyOnHand) {
                                FoundId = true;
                                JOptionPane.showMessageDialog(null, "Insufficient stock. Only " + itemQtyOnHand + " on hand. Please reduce the quantity.", "Nile Dot Com - ERROR", JOptionPane.ERROR_MESSAGE);
                                QTTextField.setText("");
                                currentItemIndex++;
                                break;
                            }
                	     
                        if(itemQuantity >= 1 && itemQuantity <= 4) {
                        	discount = 0;
                        }
                        if(itemQuantity >= 5 && itemQuantity <= 9) {
                        	discount = 0.10;
                        }
                        if(itemQuantity >= 10 && itemQuantity <= 14) {
                        	discount = 0.15;
                        }
                        if(itemQuantity >= 15 && itemQuantity <= 20) {
                        	discount = 0.20;
                        }
                     
                        double priceTot = itemQuantity*itemPrice;
                        double totalPrice = priceTot-(priceTot*discount);
                        itemSubtotal = totalPrice;
                        itemDiscount = discount;
                        
                        itemTextField.setText(itemID+" "+itemTitle+" $"+itemPrice+" "+itemQuantity+" "+discount*100+"% $"+totalPrice);
                        FoundId = true;             
                      
                     
                        confirmB.setEnabled(true);
                        processB.setEnabled(false);
            	     
                        orderSubtotal += totalPrice;
                     
                        currentItemIndex++;
                       
                        break;
                        
                    }
                    
                }
                
               
               
                if (FoundId == false) {
                	 JOptionPane.showMessageDialog(null, "item ID " + IDTextField.getText() + " not in file", "Nile Dot Com - ERROR ", JOptionPane.ERROR_MESSAGE);
                   	 currentItemIndex++;
                   	 
                }
               	 
               
                bufferedReader.close();
                fileReader.close();
                
                } 
            	catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error reading from inventory.csv", "Nile Dot Com - Current Shopping Cart Status", JOptionPane.ERROR_MESSAGE);
                }
                }
            }
    

//*****************************************************************************************************************************************************************//
    private class ConfirmButtonHandler implements ActionListener {
        private int currentSpaceIndex = 1;

        public void actionPerformed(ActionEvent e) {
            System.out.println("The Add Item to Cart Button Was Clicked...");


            itemCount++; 
            assert itemCount > 0 : "Item count is <= 0";

            itemIDArray[itemCount] = itemID;
            itemTitleArray[itemCount] = itemTitle;
            itemInStockArray[itemCount] = itemInStock;
            itemPriceArray[itemCount] = itemPrice;
            itemQuantityArray[itemCount] = itemQuantity;
            itemDiscountArray[itemCount] = itemDiscount;
            itemSubtotalArray[itemCount] = itemSubtotal;

          
            IDTextField.setText("");
            QTTextField.setText("");
            
            processB.setEnabled(true);
            confirmB.setEnabled(false);
            viewB.setEnabled(true);
            finishB.setEnabled(true);
            newb.setEnabled(true);
            exitB.setEnabled(true);

            processB.setText("Find Item #" + (itemCount + 1));
            confirmB.setText("Add Item #" + (itemCount + 1) + " To Cart");
            IDLabel.setText("Enter item ID for Item #" + (itemCount + 1) + ":");
            QTLabel.setText("Enter quantity for Item #" + (itemCount + 1) + ":");
            itemLabel.setText("Details for Item #" + (itemCount + 1) + ":");
            totalLabel.setText("Order subtotal for " + (itemCount) + " item(s):");

            JTextField currentSpace = getCurrentSpace();
            currentSpace.setText(itemID + " " + itemTitle + " " + itemPrice + " " + itemQuantity + " " + itemDiscount * 100 + "% " + itemSubtotal);

      
            currentSpaceIndex++;

      
            orderSubString = currencyFormatter.format(orderSubtotal);
            totalTextField.setText(orderSubString);
           
        }

        private JTextField getCurrentSpace() {
            try {
                return (JTextField) Grayarea.this.getClass().getDeclaredField("space" + currentSpaceIndex).get(Grayarea.this);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                e.printStackTrace();
                return null;
            }
        }
    }

//*****************************************************************************************************************************************************************/
    private class ViewButtonHandler implements ActionListener 
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		
    		System.out.println("The View Cart Button Was Clicked...");
    
            if (itemCount > 0) {

                String outputMessage = "";
                for(int i = 1; i <= itemCount; i++) {
                	outputMessage += i + ". " + itemIDArray[i] + " " + itemTitleArray[i] + " $" + itemPriceArray[i] + " " + itemQuantityArray[i] + " " + itemDiscountArray[i] + " $" + itemSubtotalArray[i] + "\n";
                }

    
                displayErrorMessage(outputMessage);
                resetGUI();

               
                itemCount++;
            } else {
               
                String errorMessage = "No items in the cart. Please add items before confirming.";
                displayErrorMessage(errorMessage);
            }
        }
    	       private void displayErrorMessage(String errorMessage) {JOptionPane.showMessageDialog(null, errorMessage, "Nile Dot Com - Current Cart Status ", JOptionPane.ERROR_MESSAGE);
        }

        private void resetGUI() {
            
        }
    }

//*****************************************************************************************************************************************************************//
  
    public class FinishButtonHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.out.println("The Check Out Button Was Clicked... ");

            String TFileName = "transaction.csv";

            double orderTaxAmount = orderSubtotal * TAX_RATE;
            double orderTotal = orderSubtotal + orderTaxAmount;

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yy hh:mm:ss a zzz");
            dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
            String timestamp = dateFormat.format(currentDate);

            String finalrecipt = ("Date:" + timestamp + "\n\n" + "Number of line item:" + itemCount + "\n\n"
                    + "Item# / ID / Title / Price / Qty / Disc % / Subtotal: " + "\n\n");

            for (int i = 1; i <= itemCount; i++) { finalrecipt += i + ". " + itemIDArray[i] + " " + itemTitleArray[i] + " $" + itemPriceArray[i] + " "
                        + itemQuantityArray[i] + " " + itemDiscountArray[i] * 100 + "% $" + itemSubtotalArray[i] + "\n";
            }

            finalrecipt += "\nOrder Subtotal: $" + orderSubtotal + "\n\n";
            finalrecipt += "Tax Rate: " + (TAX_RATE * 100) + "%\n\n";
            finalrecipt += "Tax Amount: $" + orderTaxAmount + "\n\n";
            finalrecipt += "ORDER TOTAL: $" + orderTotal + "\n\n" + "Thanks for shopping at Nile Dot Com!";

            JOptionPane.showMessageDialog(null, finalrecipt, "Nile Dot Com - FINAL INVOICE", JOptionPane.INFORMATION_MESSAGE);

            // Save the transaction to the transaction.csv file
            saveTransactionToFile(TFileName, timestamp, itemCount, finalrecipt);
        }

        private void saveTransactionToFile(String fileName, String timestamp, int itemCount, String finalrecipt) {
            FileWriter fileWriter = null;
            PrintWriter printWriter = null;

            try {
                fileWriter = new FileWriter(fileName, true);
                printWriter = new PrintWriter(fileWriter);

                String formattedTimestamp = new SimpleDateFormat("ddMMyyyyHHmmss").format(new java.util.Date());
                printWriter.println("Timestamp: " + formattedTimestamp);
                printWriter.println("Transaction Date: " + timestamp);
                printWriter.println("Number of Line Items: " + itemCount);
                printWriter.println("Order Summary:");
                printWriter.println(finalrecipt);
                printWriter.println("----------------------------------");

                JOptionPane.showMessageDialog(null, "Transaction saved to " + fileName, "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: Unable to write to transaction file.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    if (printWriter != null) {
                        printWriter.close();
                    }
                    if (fileWriter != null) {
                        fileWriter.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

//*****************************************************************************************************************************************************************/
    
    private class NewButtonHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.out.println("The Empty Cart Button Was Clicked...");
            for (int i = 1; i <= itemCount; i++) {
            	
            	itemDiscountArray[i] = 0;
            	itemPriceArray[i] = 0;
                itemQuantityArray[i] = 0;
                itemSubtotalArray[i] = 0;
                //---------------
                itemIDArray[i] = null;
                itemTitleArray[i] = null;
                itemInStockArray[i] = null;
                //---------------
                
            }
            
          
            itemCount = 0;
            orderSubtotal = 0;
            orderTotal = 0;
         
            IDTextField.setText("");
            QTTextField.setText("");
            itemTextField.setText("");
            totalTextField.setText("");
            
            processB.setText("Find Item #" + (itemCount + 1));
            confirmB.setText("Add Item #" + (itemCount + 1) + " To Cart");
            IDLabel.setText("Enter item ID for Item #" + (itemCount + 1) + ":");
             QTLabel.setText("Enter quantity for Item #" + (itemCount + 1) + ":");
            itemLabel.setText("Details for Item #" + (itemCount + 1) + ":");
            totalLabel.setText("Order subtotal for " + (itemCount) + " item(s):");

         
            confirmB.setEnabled(false);
            viewB.setEnabled(false);
            finishB.setEnabled(false);
            newb.setEnabled(false);
            exitB.setEnabled(true);
        }
    }

//*****************************************************************************************************************************************************************//
    private class ExitButtonHandler implements ActionListener
    {
   	public void actionPerformed(ActionEvent e){
   		 		System.out.println("The Exit Button Was Clicked...");
   		 		System.exit(0);	
   		 	}
   		 	
   		 }
    //***************************************** ************************************************************//
    public void centerFrame(int frameWidth, int frameHeight){
    	Toolkit aToolkit = Toolkit.getDefaultToolkit();
    	Dimension screen = aToolkit.getScreenSize();
    	int xPositionOfFrame = (screen.width - frameWidth) / 2;
    	int yPositionOfFrame = (screen.height - frameHeight) / 2;
    	setBounds(xPositionOfFrame, yPositionOfFrame, frameWidth, frameHeight);
    	
    }
//*****************************************************************************************************************************************************************//
	public static void main(String[] args){	
		JFrame aNeStore = new Grayarea(); 
		aNeStore.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		aNeStore.setVisible(true); 
	}
	
}
