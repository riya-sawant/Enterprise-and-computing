/*
Name: Riya Sawant
Course: CNT 4714 Spring 2024
Assignment title: Project 3 – A Specialized Accountant Application
Date: March 10, 2024
Class: <name of class goes here>
*/
package try3;



import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class OPP extends JFrame {
    private JLabel dbUrlLabel, userPropsLabel, usernameLabel, passwordLabel, connectionStatusLabel;
    private JButton connectButton, clearSQLButton, executeSQLButton, clearResultButton;
    private JTextField usernameField;
    private JComboBox<String> dbUrlComboBox, userPropsComboBox;
    private JTextArea sqlCommandArea;
    private JPasswordField passwordField;
    private DefaultTableModel tableModel = null;
    private JTable resultTable;
    private boolean isConnected = false;
    private Connection connection = null;

    public OPP() throws Exception {
        createComponents();

        connectButton.addActionListener(e -> {
            connectToDatabase();
        });

        clearSQLButton.addActionListener(e -> sqlCommandArea.setText(""));

        executeSQLButton.addActionListener(e -> {
            if (isConnected) {
                executeSQLCommand();
            } else {
                JOptionPane.showMessageDialog(this, "Not connected to the database.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        clearResultButton.addActionListener(e -> {
            resultTable.setModel(new DefaultTableModel());
            tableModel = null;
        });

        JPanel topLabel1 = new JPanel();
        JPanel topLabel2 = new JPanel();
        topLabel1.add(new JLabel("Enter Database Information"));
        topLabel2.add(new JLabel("Enter An SQL Command"));

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 4, 10, 0));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));
        buttonsPanel.add(connectionStatusLabel);
        buttonsPanel.add(connectButton);
        buttonsPanel.add(clearSQLButton);
        buttonsPanel.add(executeSQLButton); // Add execute button here

        JPanel labelsAndTextFieldsPanel = new JPanel(new GridLayout(4, 2, 4, 2));
        labelsAndTextFieldsPanel.add(dbUrlLabel);
        labelsAndTextFieldsPanel.add(dbUrlComboBox);
        labelsAndTextFieldsPanel.add(userPropsLabel);
        labelsAndTextFieldsPanel.add(userPropsComboBox);
        labelsAndTextFieldsPanel.add(usernameLabel);
        labelsAndTextFieldsPanel.add(usernameField);
        labelsAndTextFieldsPanel.add(passwordLabel);
        labelsAndTextFieldsPanel.add(passwordField);

        JPanel topPanel = new JPanel(new GridLayout(2, 1, 20, 2));
        topPanel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        topPanel.add(topLabel1);
        topPanel.add(topLabel2);
        topPanel.add(labelsAndTextFieldsPanel);
        topPanel.add(sqlCommandArea);

        JPanel containerPanel = new JPanel();
        containerPanel.add(clearResultButton);
        containerPanel.setOpaque(true);

        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.add(new JScrollPane(resultTable), BorderLayout.CENTER);
        resultPanel.add(containerPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(buttonsPanel, BorderLayout.CENTER);
        add(resultPanel, BorderLayout.SOUTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            public void windowClosed(WindowEvent event) {
                try {
                    if (connection != null && !connection.isClosed()) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                System.exit(0);
            }
        });
    }

    private void createComponents() throws Exception {
        String[] dbUrlOptions = { "operationslog" };
        String[] userPropsOptions = { "theaccountant" };

        dbUrlLabel = new JLabel("DB URL Properties");
        userPropsLabel = new JLabel("User Properties");
        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");
        connectionStatusLabel = new JLabel("No Connection Now");
        connectionStatusLabel.setForeground(Color.RED);
        connectionStatusLabel.setOpaque(true);
        connectionStatusLabel.setBackground(Color.BLACK);

        dbUrlComboBox = new JComboBox<>(dbUrlOptions);
        dbUrlComboBox.setSelectedIndex(0);
        userPropsComboBox = new JComboBox<>(userPropsOptions);

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        sqlCommandArea = new JTextArea(3, 75);
        sqlCommandArea.setWrapStyleWord(true);
        sqlCommandArea.setLineWrap(true);

        connectButton = createStyledButton("Connect to Database", Color.BLUE, Color.black);
        clearSQLButton = createStyledButton("Clear SQL Command", Color.WHITE, Color.RED);
        executeSQLButton = createStyledButton("Execute SQL Command", Color.GREEN, Color.BLACK);
        clearResultButton = createStyledButton("Clear Result Window", Color.YELLOW, Color.BLACK);

        tableModel = new DefaultTableModel(); // Initialize the instance variable tableModel
        resultTable = new JTable(tableModel);
    }

    private JButton createStyledButton(String text, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setBackground(background);
        button.setOpaque(true);
        button.setForeground(foreground);
        button.setBorderPainted(true);
        return button;
    }

    private void connectToDatabase() {
        String dbUrl = "jdbc:mysql://localhost:3306/operationslog";
        String username = "theaccountant";
        String password = "theaccountant";
        String enteredUsername = usernameField.getText();

        try {
            // Check if the entered username matches the expected username
            if (!enteredUsername.equals(username)) {
                connectionStatusLabel.setText("NOT CONNECTED -Use Credientails Do Not Match Properties File!");
                connectionStatusLabel.setForeground(Color.RED);
                return;
            }

            connection = DriverManager.getConnection(dbUrl, username, password);
            connectionStatusLabel.setText("Connected to: jdbc:mysql://localhost:3306/operationslog");
            connectionStatusLabel.setForeground(Color.GREEN);
            isConnected = true;
        } catch (SQLException e) {
            connectionStatusLabel.setText("NOT CONNECTED");
            connectionStatusLabel.setForeground(Color.RED);
        }
    }


    private void executeSQLCommand() {
        String sqlQuery = sqlCommandArea.getText();
        try (Statement statement = connection.createStatement()) {
            boolean isResultSet = statement.execute(sqlQuery);

            // If the query returns a ResultSet (like SELECT), process the result
            if (isResultSet) {
                ResultSet resultSet = statement.getResultSet();

                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();

                tableModel.setRowCount(0);
                tableModel.setColumnCount(0);

                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    tableModel.addColumn(metaData.getColumnName(columnIndex));
                }

                while (resultSet.next()) {
                    Object[] rowData = new Object[columnCount];
                    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                        rowData[columnIndex - 1] = resultSet.getObject(columnIndex);
                    }
                    tableModel.addRow(rowData);
                }

                // Update the operationscount table
                String updateCountQuery = "UPDATE operationscount SET count = count + 1 WHERE operation = ?";
                try (PreparedStatement updateStatement = connection.prepareStatement(updateCountQuery)) {
                    updateStatement.setString(1, sqlQuery.split("\\s+")[0]); // Extract the operation from the SQL query
                    updateStatement.executeUpdate();
                }
            } else {
                // If the query does not return a ResultSet (like INSERT, UPDATE, DELETE),
                // show a success message
                int updatedRows = statement.getUpdateCount();
                if (updatedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Query executed successfully. " + updatedRows + " rows affected.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    
                    // Update the operationscount table for non-SELECT queries
                    String updateCountQuery = "UPDATE operationscount SET count = count + 1 WHERE operation = ?";
                    try (PreparedStatement updateStatement = connection.prepareStatement(updateCountQuery)) {
                        updateStatement.setString(1, sqlQuery.split("\\s+")[0]); // Extract the operation from the SQL query
                        updateStatement.executeUpdate();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Query executed successfully. No rows affected.", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error executing SQL command: " + e.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                OPP app = new OPP();
                app.pack();
                app.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}