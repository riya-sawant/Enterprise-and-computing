
/* Name: Riya Sawant
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/
package testing2;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.text.DecimalFormat;

public class newtwo {
    private static final int DEPOSITOR_THREADS = 5;
    private static final int WITHDRAWAL_THREADS = 10;
    private static final int AUDITOR_THREADS = 2;

    public static void main(String[] args) {
        Account account = new Account();
        ExecutorService executor = Executors.newFixedThreadPool(DEPOSITOR_THREADS + WITHDRAWAL_THREADS + AUDITOR_THREADS, new CustomThreadFactory("WT"));

        // Start depositor threads
        for (int i = 0; i < DEPOSITOR_THREADS; i++) {
            executor.execute(new Depositor(account));
        }

        // Start withdrawal threads
        for (int i = 0; i < WITHDRAWAL_THREADS; i++) {
            executor.execute(new Withdrawal(account));
        }

        // Start InternalBank auditor thread
        executor.execute(new InternalBank(account, 1));

        // Start TreasuryDept auditor thread
        executor.execute(new TreasuryDept(account, 2));

        // Shutdown the executor after a few seconds (stop the simulation)
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        executor.shutdown();
    }
}

class Account {
    private int balance;
    private int transactionNumber;
    private Lock lock;
    private Condition sufficientFunds;
    
    private volatile boolean readyForAudit;

    public Account() {
        balance = 0;
        transactionNumber = 0;
        lock = new ReentrantLock();
        sufficientFunds = lock.newCondition();
        readyForAudit = false;
    }

    public void deposit(int amount) {
        lock.lock();
        try {
            balance += amount;
            transactionNumber++;
            System.out.printf("Deposit: Agent D%s deposited $%d, Balance is $%d, Transaction Number: %d\n",
                    Thread.currentThread().getName(), amount, balance, transactionNumber);

            if (amount > 350) {
                System.out.printf("\n*** Flagged transaction - Depositor Agent %s made a deposit in excess of $350.00 USD - See Flagged Transaction \n\n",
                        Thread.currentThread().getName());
                flagTransaction("deposit", amount, Thread.currentThread().getName()); // Pass agent number
            }

            sufficientFunds.signalAll();
            readyForAudit = true; // Set readyForAudit to true after each deposit
        } finally {
            lock.unlock();
        }
    }

    public void withdraw(int amount) {
        lock.lock();
        try {
            while (balance < amount) {
                System.out.printf("Withdrawal: Agent %s withdraws $%d (****) Withdrawal BLOCKED - insufficient funds!!! \n",
                        Thread.currentThread().getName(), amount);
                try {
                    sufficientFunds.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            balance -= amount;
            transactionNumber++;
            System.out.printf("Withdrawal: Agent W%s withdrew $%d, Balance is $%d, Transaction Number: %d\n",
                    Thread.currentThread().getName(), amount, balance, transactionNumber);

            if (amount > 75) {
                System.out.printf("\n*** Flagged transaction - Withdrawal in excess of $75.00USD - See Flagged Transaction Log.\n\n",
                        Thread.currentThread().getName());
                flagTransaction("withdrawal", amount, Thread.currentThread().getName()); // Pass agent number
            }

            readyForAudit = true; // Set readyForAudit to true after each withdrawal
        } finally {
            lock.unlock();
        }
    }

    private void flagTransaction(String type, int amount, String agentNumber) { // Add agent number parameter
        // Log flagged transactions to a separate file
        String fileName = "transaction2.csv";
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            LocalDateTime dateTime = LocalDateTime.now();
            ZoneId zoneId = ZoneId.of("America/New_York"); // EST time zone
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss").withZone(zoneId);
            String timestamp = dateTime.format(formatter);
            DecimalFormat df = new DecimalFormat("#0.00");
            String formattedAmount = " issued withdrawal of $" + df.format(amount);
            writer.printf("%s, Agent %s, %s at: %s EST   Transaction Number : %d\n", type, agentNumber, formattedAmount, timestamp, transactionNumber); // Include agent number
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void waitUntilReadyForAudit() throws InterruptedException {
        lock.lock();
        try {
            while (!readyForAudit) {
                sufficientFunds.await();
            }
        } finally {
            lock.unlock();
        }
    }

    public void markReadyForAudit() {
        lock.lock();
        try {
            readyForAudit = false; // Reset readyForAudit after each audit
            sufficientFunds.signalAll();
        } finally {
            lock.unlock();
        }
    }

    public int getBalance() {
        return balance;
    }
}

class Depositor implements Runnable {
    private static final Random random = new Random();
    private Account account;

    public Depositor(Account account) {
        this.account = account;
    }

    @Override
    public void run() {
        while (true) {
            try {
                int amount = random.nextInt(500) + 1;
                account.deposit(amount);

                // Sleep for a random period 
                Thread.sleep(random.nextInt(100)); // Sleep for a random period
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Withdrawal implements Runnable {
    private static final Random random = new Random();
    private Account account;

    public Withdrawal(Account account) {
        this.account = account;
    }

    @Override
    public void run() {
        while (true) {
            try {
                int amount = random.nextInt(99) + 1;
                account.withdraw(amount);

                if (Runtime.getRuntime().availableProcessors() > 1) {
                    // Sleep 
                    Thread.sleep(random.nextInt(10));
                } else {
                    
                    Thread.yield();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class InternalBank implements Runnable {
    private static final Random random = new Random();
    private Account account;
    private int transactionsSinceLastAudit;
    private long lastAuditTime;

    public InternalBank(Account account, int auditorId) {
        this.account = account;
        this.transactionsSinceLastAudit = 0;
        this.lastAuditTime = System.currentTimeMillis();
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
               
                Thread.sleep(random.nextInt(500) + 100); // Sleep 

                account.waitUntilReadyForAudit(); 

                // elapsed time since last audit
                long currentTime = System.currentTimeMillis();
                long elapsedTime = currentTime - lastAuditTime;

                if (elapsedTime > 100) { // Adjust this time interval 
                    int currentBalance = account.getBalance();
                    
                    System.out.printf("**********************");
                    System.out.printf("\n      Internal bank auditor finds Current account balance is $%d,    Number of Transactions since last internal audit: %d\n**********************\n",
                            currentBalance, transactionsSinceLastAudit);
                    transactionsSinceLastAudit = 0; // Reset counter
                    lastAuditTime = currentTime; // Update last audit time
                    account.markReadyForAudit(); // Mark account ready for audit
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void incrementTransactionsSinceLastAudit() {
        transactionsSinceLastAudit++;
    }
}

class TreasuryDept implements Runnable {
    private static final Random random = new Random();
    private Account account;
    private int transactionsSinceLastAudit;
    private long lastAuditTime;

    public TreasuryDept(Account account, int auditorId) {
        this.account = account;
        this.transactionsSinceLastAudit = 0;
        this.lastAuditTime = System.currentTimeMillis();
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
               
                Thread.sleep(random.nextInt(500) + 100); // Sleep 

                account.waitUntilReadyForAudit(); 

                //elapsed time since last audit
                long currentTime = System.currentTimeMillis();
                long elapsedTime = currentTime - lastAuditTime;

                if (elapsedTime > 100) { // Adjust this time interval 
                    int currentBalance = account.getBalance();
                    System.out.printf("**********************");
                    System.out.printf("\n       Treasury Department auditor finds Current account balance is $%d,  Number of Transactions since last treasury audit: %d\n**********************\n",
                            currentBalance, transactionsSinceLastAudit);
                    transactionsSinceLastAudit = 0; // Reset counter
                    lastAuditTime = currentTime; // Update last audit time
                    account.markReadyForAudit(); // Mark account ready for audit
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void incrementTransactionsSinceLastAudit() {
        transactionsSinceLastAudit++;
    }
}


class CustomThreadFactory implements ThreadFactory {
    private final String namePrefix;

    public CustomThreadFactory(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    @Override
    public Thread newThread(Runnable r) {
       
        Thread t = new Thread(r);
        t.setName(namePrefix + t.getId());
        return t;
    }
}

